$("#profile").click(function () {
    $(".animate-profile").toggle(function () {
    });
});
$("#notification").click(function () {
    $(".animate-notification").toggle(function () {
    });
});
$(" .filter ").click(function () {
    $(".drop-down-filter").toggle(function () {
    });
});